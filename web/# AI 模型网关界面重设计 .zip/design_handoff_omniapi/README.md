# Handoff: OmniAPI 官网首页 + 设计系统

## Overview
OmniAPI 是一个 AI 模型聚合网关(中转站,域名 `api.omniapi.top`)。本包包含两份设计参考:
1. **首页(长滚动着陆页)** — 概念「受控的极速 / Controlled Velocity」,F1 遥测仪表 × 顶级技术基建的视觉语言。
2. **设计系统文档** — 配色、字体、组件、动效与用法规范,作为后续所有页面的统一参照。

> 注:本包中的「首页」指经过完整打磨的 **`OmniAPI 控速着陆页.dc.html`**(酸性黄绿主题,与设计系统一致)。项目里另有一个较早的绿色版 `OmniAPI 首页.dc.html`,已被此版取代——如需以那一版为准请告知。

## About the Design Files
本包中的 `.dc.html` 文件是**用 HTML 制作的设计参考(高保真原型)**,用于展示最终的外观与交互意图,**不是要直接照搬的生产代码**。任务是:**在目标代码库的现有技术栈中(React / Vue / 等)按其既有模式重建这些设计**。若尚无前端环境,则选择最合适的框架实现。

`.dc.html` 依赖同目录的 `support.js` 运行时才能在浏览器打开预览;实现时无需移植该运行时,按下方 token 与说明用你们自己的组件体系重建即可。

## Fidelity
**高保真(hifi)**。颜色、字号、字距、间距、圆角、动效缓动均为最终值,请按 token 像素级还原,并用代码库现有的组件库承接。

## ⚠ 实现要点(重要)
原型里的「滚动揭示 / 标题入场」用了 `requestAnimationFrame` 每帧写 `transform` 的写法——这是**为适配本预览环境的时间线限制**而做的,**不是推荐做法**。在真实代码库中请用标准方案:
- 滚动揭示:`IntersectionObserver` + CSS `transition`(或框架的动画库,如 Framer Motion 的 `whileInView`)。
- 进度条 / 视差:监听 `scroll`(`requestAnimationFrame` 节流)。
- 入场动态模糊:CSS `@keyframes` 或动画库。
缓动统一用 `cubic-bezier(0.16, 1, 0.3, 1)`,**禁止弹跳**。

---

## Design Tokens

### Colors
| Token | Hex / Value | 用途 |
|---|---|---|
| `accent` | `#CDFF4E` | 酸性黄绿,唯一高亮色。仅用于主 CTA、激活态、关键数据、状态正常。**绝不大面积铺、不满屏发光** |
| `accent-ink` | `#06070A` | lime 按钮上的文字色 |
| `bg-base` | `#06070A` | 冷调近黑主背景,大面积留黑 |
| `panel-bg` | `#0F1116` | 面板底色 |
| `text-strong` | `#F4F6F8` | 标题 |
| `text-primary` | `#ECEEF0` | 高对比正文 / 默认前景 |
| `text-secondary` | `#9AA1AB` | 次要正文 |
| `text-muted` | `#888F99` | 弱文字 |
| `text-faint` | `#5B626D` | 极弱标签 / mono 小标 |
| `depth-blue` | `#1A3468` (及 `#1C3462`) | 第 1 屏 mesh 渐变景深蓝 |
| `danger` | `#FF7A7A` | 仅用于 DON'T / 错误提示文字 |

### Borders（透明描边层级，建立在深底之上）
| Token | Value |
|---|---|
| `border-weak` | `rgba(255,255,255,0.06)` |
| `border-mid` | `rgba(255,255,255,0.12)` |
| `border-strong` | `rgba(255,255,255,0.16)` |
| `border-accent` | `rgba(205,255,78,0.4)` |
| `panel-glass` | `linear-gradient(180deg, rgba(255,255,255,0.035), rgba(255,255,255,0.01))` |

### Typography
- **Display / 标题**:`Archivo`(Google Fonts,权重 800–900)。字距收紧:H1 `-0.03em`,H2 `-0.02em`。中文用同字重无衬线(苹方 / 微软雅黑)承接。
- **Data / 技术内容**:`JetBrains Mono`(权重 400–700)。用于延迟、令牌、模型 ID、用量、API 地址、所有 mono 小标。小标常用大写 + 字距 `0.1–0.2em`。

| 角色 | 字体 | 字号 | 字重 | 其他 |
|---|---|---|---|---|
| H1 (hero) | Archivo | `clamp(64px, 12.5vw, 210px)` | 900 | `-0.03em`, line-height .92 |
| H2 (section) | Archivo | `clamp(40px, 5.4vw, 82px)` | 800 | `-0.02em` |
| Body | system sans | `16–17px` | 400–500 | line-height 1.65–1.7,色 `#9AA1AB` |
| Mono label | JetBrains Mono | `11–13px` | 500–600 | `0.18em`,大写,色 `#CDFF4E` 或 `#5B626D` |
| Data readout | JetBrains Mono | `15–46px` | 600 | 关键值用 `accent`,其余 `#ECEEF0` |

### Radius
- 按钮 / 标签:`7–9px`
- 输入框:`10px`
- 卡片 / 面板:`14–16px`
- 状态 pill:`999px`

### Shadow / Glow（克制使用）
- 主 CTA:`box-shadow: 0 0 0 1px rgba(205,255,78,.4), 0 10px 40px -10px rgba(205,255,78,.5)`
- 发光点(状态):`box-shadow: 0 0 8px #CDFF4E`
- **不要**彩色厚重投影、不要处处发光描边。

### Motion
- 缓动:`cubic-bezier(0.16, 1, 0.3, 1)`(精准、有重量、无弹跳)
- 揭示:进入视口 → `translateY(30px)` + opacity 淡入,约 0.9s
- 按钮 hover:`translateY(-2px)`,0.15s
- HUD 状态点:opacity 闪烁 2s 循环

---

## Screens / Views — 首页(单一长滚动页,**不拆分**)
全局:固定顶部导航(毛玻璃)、顶部滚动进度条(2px,lime)、全站 film-grain 噪点叠加、径向暗角。

导航项(保持原样,勿增删):**首页 / 控制台 / 模型广场 / 文档**;右侧:状态指示「ALL SYSTEMS NOMINAL」+ 用户头像 `dxp`。

页面按顺序由 5 个 section 组成:

1. **01 智能 / Frontier(开场)**
   - 背景:canvas 绘制的缓慢呼吸 mesh 渐变(深蓝 `#1A3468`/`#1C3462` + 一抹 lime),外加径向暗角。
   - 内容居中:mono 小标「永远站在模型的最前沿」、大标题 **「前沿,即刻可用」**、副文案、主 CTA「进入控制台 →」+ 幽灵按钮「阅读文档」。
   - 底部:**模型 ticker** 横向无限滚动(首尾相接无断裂),标签为厂商名(GPT / Claude(accent) / Gemini / DeepSeek / Grok / Llama / Qwen / Kimi / Mistral / GLM)——**只写厂商名,不带版本号、不带 NEW**,便于维护。

2. **02 急速 / Velocity(原 Hero)**
   - 背景:canvas 速度光流(横向飞驰光条,带运动残影,少量 lime)。两层深色渐变压暗保证文字清晰。
   - HUD:四角细线刻度;四个角的等宽实时读数(P99 LATENCY `47ms`、REQUESTS/SEC `~12,840`、MODELS ONLINE `38`、NODE `CTRL-CENTER · AP-EAST`)。延迟与请求数每约 1.3s 轻微跳动。
   - 内容(左对齐):mono 小标「OMNIAPI · AI GATEWAY TELEMETRY」、超大标题 **「极速」**(入场带轻微动态模糊 + 斜切滑入)、其下副文案两行「极速且精密的前沿 AI 接口控制中心。/ 一个端点,稳定中转全部大模型。」、再下方 mono 标「CONTROLLED VELOCITY」。
   - 底部居中:SCROLL 指示 + 跳动圆点。

3. **03 聚合 / Aggregation**
   - 中心:lime 圆角节点(∞),带两圈向外扩散的脉冲环。
   - SVG 8 条曲线,**从各模型标签静态连到中心节点**(不随滚动变化),光点沿线流动。标签分布在四周:OpenAI / Claude(accent) / Gemini / DeepSeek / xAI Grok(accent) / Mistral / Qwen / Kimi。
   - 顶部:mono 小标「// 03 — AGGREGATION」、标题「分散接入,汇成一束」+ 描述。
   - 中下:点题大标题「一个端点,接入全部」+ mono「// 1 ENDPOINT · 30+ PROVIDERS · UNIFIED」。

4. **04 稳定 / Stability**（左右两栏）
   - 左:mono 小标「// PRECISION · ROCK-SOLID」、标题 **「稳定 / 从不断线」**、描述;一排指标:`99.99%` 30D UPTIME、实时运行时计数 `312d hh:mm:ss`、P50 `28ms` / P99 `47ms` / 错误率 `0.00%`(lime) / 故障切换 `<1s`。
   - 右:遥测面板 — 顶栏「TELEMETRY · SIGNAL ● STABLE」,canvas 永不断裂的示波器正弦波(lime 发光),下方 16×3 共 48 个状态灯(全 lime,随机闪烁)+「48 / 48 OK」。

5. **05 收尾 / CTA**
   - 四角 HUD 刻度呼应首屏。mono 小标「// ENTER THE CONTROL CENTER」、超大标题 **「掌控你的 / AI 接口」**、副文案、主 CTA「进入控制台 →」+ 幽灵「查看文档」。

底部:**超大 OMNIAPI 品牌字**(Archivo 900,`clamp(96px,23vw,420px)`,深色渐变描字 `#1b2026→#0c0e12`,下方一道 lime 渐隐线)→ 多列页脚(品牌 + api.omniapi.top、控制台/模型广场/文档/状态、版权 mono)。

## Interactions & Behavior
- 顶部进度条随滚动 `scaleX`。
- 各 section 进入视口时上移淡入(用 IntersectionObserver 实现)。
- 02 屏标题入场:动态模糊 + 轻微斜切滑入(约 0.9s,一次性)。
- 02 屏 HUD 数字每 ~1.3s 轻微变化;04 屏运行时计数每秒 +1。
- 03 屏:连线静态,仅光点沿线流动(不随滚动)。
- 04 屏示波器与状态灯持续动画。
- ticker / mesh / 速度光流为持续动画;进入视口才绘制以省性能。
- 按钮 hover 上移;链接 hover 转 lime。
- API 基址输入框旁「复制」按钮:点击复制 `https://api.omniapi.top/v1/chat/completions`,显示「已复制」反馈(原型中在着陆页改版文件;首页如需可复用同规范)。

## State Management
- `scrollProgress`(进度条)
- 各 reveal 节点的 `inView` 布尔(IntersectionObserver)
- HUD 读数定时器(setInterval)+ 运行时计数器
- `copied` 短暂态(复制反馈)
- 真实接入时上述读数应来自后端监控接口,原型中为示意值。

## Assets
- 字体:Google Fonts — Archivo、JetBrains Mono。
- 图标:内联 SVG(stroke 风格,1.6 线宽)。
- 噪点:内联 SVG `feTurbulence` data-URI。
- Logo:文字 + `∞` 字符占位(无图片资源)。如有正式 logo 请替换。
- 第 1/2 屏 mesh 与速度场为 canvas 程序化绘制,无图片素材。

## Files
- `OmniAPI 控速着陆页.dc.html` — 首页(长滚动着陆页)设计参考。
- `OmniAPI 设计系统.dc.html` — 设计系统 / 品牌规范(配色、字体、组件、动效、DO/DON'T)。
- `support.js` — 仅用于在浏览器打开上面两个 `.dc.html` 预览的运行时;实现时不需要移植。
